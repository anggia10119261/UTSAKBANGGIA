package com.example.a10119261uts.ui.gallery;

/*
NIM     : 10119261
Nama    : Anggia Regina Wulandari
Kelas   : IF-7
 */

public class ModelGallery {
    int image;

    public ModelGallery(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
