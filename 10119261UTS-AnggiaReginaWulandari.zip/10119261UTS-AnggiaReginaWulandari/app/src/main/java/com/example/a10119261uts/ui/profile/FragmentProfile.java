package com.example.a10119261uts.ui.profile;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.a10119261uts.DialogAbout;
import com.example.a10119261uts.R;

import androidx.fragment.app.Fragment;

/*
NIM     : 10119261
Nama    : Anggia Regina Wulandari
Kelas   : IF-7
 */

public class FragmentProfile extends Fragment {
    ImageView Instagram, Whatsapp, Telegram, Gmail, Github, Linkedin, Maps;
    TextView Abouts;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_profile, container, false);

        Instagram = root.findViewById(R.id.instagram);
        Whatsapp = root.findViewById(R.id.whatsapp);
        Telegram = root.findViewById(R.id.telegram);
        Gmail = root.findViewById(R.id.gmail);
        Github = root.findViewById(R.id.github);
        Linkedin = root.findViewById(R.id.linkedin);
        Maps = root.findViewById(R.id.maps);
        Abouts = root.findViewById(R.id.about);

        Instagram.setOnClickListener(v -> {
            Intent insta = new Intent();
            insta.setAction(Intent.ACTION_VIEW);
            insta.addCategory(Intent.CATEGORY_BROWSABLE);
            insta.setData(Uri.parse("https://www.instagram.com/nadiasfmh"));
            startActivity(insta);
        });

        Whatsapp.setOnClickListener(view -> {
            Intent whatsapp = new Intent();
            whatsapp.setAction(Intent.ACTION_VIEW);
            whatsapp.addCategory(Intent.CATEGORY_BROWSABLE);
            whatsapp.setData(Uri.parse("https://wa.me/081"));
            startActivity(whatsapp);
        });

        Telegram.setOnClickListener(view -> {
            Intent telegram = new Intent();
            telegram.setAction(Intent.ACTION_VIEW);
            telegram.addCategory(Intent.CATEGORY_BROWSABLE);
            telegram.setData(Uri.parse("https://t.me/anggiaregina"));
            startActivity(telegram);
        });

        Gmail.setOnClickListener(view -> {
            Intent gmail = new Intent();
            gmail.setAction(Intent.ACTION_VIEW);
            gmail.addCategory(Intent.CATEGORY_BROWSABLE);
            gmail.setData(Uri.parse("mailto:anggia.10119278@mahasiswa.unikom.ac.id"));
            startActivity(gmail);
        });


        Github.setOnClickListener(view -> {
            Intent github = new Intent();
            github.setAction(Intent.ACTION_VIEW);
            github.addCategory(Intent.CATEGORY_BROWSABLE);
            github.setData(Uri.parse("https://github.com/anggiaregina"));
            startActivity(github);
        });

        Linkedin.setOnClickListener(view -> {
            Intent linkedin = new Intent();
            linkedin.setAction(Intent.ACTION_VIEW);
            linkedin.addCategory(Intent.CATEGORY_BROWSABLE);
            linkedin.setData(Uri.parse("https://goo.gl/maps/YECsFawuTb1iQkEZA"));
            startActivity(linkedin);
        });

        Maps.setOnClickListener(view -> {
            Intent map = new Intent();
            map.setAction(Intent.ACTION_VIEW);
            map.addCategory(Intent.CATEGORY_BROWSABLE);
            map.setData(Uri.parse("https://goo.gl/maps/aNSMKSQxw2PygyBq9"));
            startActivity(map);
        });

        Abouts.setOnClickListener(view -> {
            DialogAbout DialogAbout = new DialogAbout();
            DialogAbout.show(requireFragmentManager(),"Anggia Regina Wulandari");
        });

        return root;
    }
}
